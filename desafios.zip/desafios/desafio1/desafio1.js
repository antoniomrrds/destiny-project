//  const reverse = (word) => word.split("").reverse().join("");

const reverse = (word) => {
  let newWordReverse = "";
  const size = word.length;
  for (let index = size - 1; index > -1; index = index - 1) {
    newWordReverse += word[index];
  }
  return newWordReverse;
};
const js = "node-js";
const name = "marcos";

console.log(reverse(js));
console.log(reverse(name));
